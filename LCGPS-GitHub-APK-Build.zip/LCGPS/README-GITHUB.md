# LCGPS — build online

1. Upload this project to a GitHub repository.
2. Open the **Actions** tab.
3. Select **Build LCGPS APK**.
4. Tap **Run workflow**.
5. Open the completed workflow run.
6. In **Artifacts**, download **LCGPS-APK**.
7. Extract the downloaded artifact ZIP and install `app-debug.apk`.

The APK is a debug/test build. A Google Maps API key is required for the map to display correctly; replace `YOUR_GOOGLE_MAPS_API_KEY` in `app/src/main/AndroidManifest.xml` before building.
