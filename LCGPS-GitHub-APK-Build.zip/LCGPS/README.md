# LCGPS

Prima versione Android: mappa, selezione punto, teletrasporto, joystick e mock GPS.

## Per compilare
1. Apri la cartella in Android Studio.
2. Sostituisci `YOUR_GOOGLE_MAPS_API_KEY` nel manifest con una chiave Google Maps SDK for Android.
3. Avvia su un dispositivo Android.
4. Per il mock GPS, abilita le Opzioni sviluppatore e seleziona LCGPS come app di posizione simulata.

Questa versione è un prototipo gratuito e non include servizi a pagamento.
