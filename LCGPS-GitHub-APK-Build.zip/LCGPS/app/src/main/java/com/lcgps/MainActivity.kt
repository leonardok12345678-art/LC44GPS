package com.lcgps

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.*

class MainActivity : AppCompatActivity(), OnMapReadyCallback {
    private lateinit var map: GoogleMap
    private lateinit var fused: FusedLocationProviderClient
    private var marker: Marker? = null
    private var virtual = LatLng(41.9028, 12.4964)
    private var mockEnabled = false
    private val step = 0.00025

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fused = LocationServices.getFusedLocationProviderClient(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFFFFF.toInt())
        }

        val title = TextView(this).apply {
            text = "  LCGPS"
            textSize = 22f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(0xFF111111.toInt())
            setPadding(16, 8, 16, 8)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 58))

        val mapView = MapView(this)
        mapView.onCreate(savedInstanceState)
        mapView.getMapAsync(this)
        root.addView(mapView, LinearLayout.LayoutParams(-1, 0, 1f))

        val status = TextView(this).apply {
            text = "  Modalità simulazione: disattivata"
            textSize = 14f
            setPadding(16, 10, 16, 10)
        }
        root.addView(status)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(12, 4, 12, 12)
        }

        val row1 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val up = Button(this).apply { text = "▲" }
        val down = Button(this).apply { text = "▼" }
        val left = Button(this).apply { text = "◀" }
        val right = Button(this).apply { text = "▶" }
        val teleport = Button(this).apply { text = "TELETRASPORTA" }
        val enable = Button(this).apply { text = "ABILITA MOCK GPS" }

        row1.addView(up, LinearLayout.LayoutParams(70, 60))
        row1.addView(down, LinearLayout.LayoutParams(70, 60))
        controls.addView(row1)

        val row2 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row2.addView(left, LinearLayout.LayoutParams(70, 60))
        row2.addView(right, LinearLayout.LayoutParams(70, 60))
        controls.addView(row2)

        controls.addView(teleport)
        controls.addView(enable)
        root.addView(controls)

        setContentView(root)

        fun move(dLat: Double, dLng: Double) {
            virtual = LatLng(virtual.latitude + dLat, virtual.longitude + dLng)
            updateMarker()
            if (mockEnabled) pushMockLocation()
        }
        up.setOnClickListener { move(step, 0.0) }
        down.setOnClickListener { move(-step, 0.0) }
        left.setOnClickListener { move(0.0, -step) }
        right.setOnClickListener { move(0.0, step) }

        teleport.setOnClickListener {
            if (::map.isInitialized) {
                virtual = map.cameraPosition.target
                updateMarker()
                if (mockEnabled) pushMockLocation()
            }
        }

        enable.setOnClickListener {
            if (!isMockLocationApp()) {
                AlertDialog.Builder(this)
                    .setTitle("Attiva LCGPS")
                    .setMessage("Per simulare la posizione, Android richiede di selezionare LCGPS come app di posizione simulata nelle Opzioni sviluppatore.")
                    .setPositiveButton("Apri impostazioni") { _, _ ->
                        startActivity(android.content.Intent(Settings.ACTION_SETTINGS))
                    }
                    .setNegativeButton("Annulla", null).show()
            } else {
                mockEnabled = true
                status.text = "  Modalità simulazione: ATTIVA"
                pushMockLocation()
            }
        }
    }

    override fun onMapReady(g: GoogleMap) {
        map = g
        map.uiSettings.isZoomControlsEnabled = true
        map.uiSettings.isMyLocationButtonEnabled = true
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(virtual, 12f))
        map.setOnMapClickListener { point ->
            virtual = point
            updateMarker()
            if (mockEnabled) pushMockLocation()
        }
        updateMarker()
    }

    private fun updateMarker() {
        if (!::map.isInitialized) return
        marker?.remove()
        marker = map.addMarker(MarkerOptions().position(virtual).title("LCGPS"))
        map.animateCamera(CameraUpdateFactory.newLatLng(virtual))
    }

    private fun isMockLocationApp(): Boolean {
        return try {
            Settings.Secure.getString(contentResolver, "mock_location") != null
        } catch (_: Exception) { false }
    }

    private fun pushMockLocation() {
        val loc = Location("LCGPS").apply {
            latitude = virtual.latitude
            longitude = virtual.longitude
            altitude = 0.0
            accuracy = 3f
            speed = 0f
            time = System.currentTimeMillis()
        }
        try {
            fused.setMockMode(true)
            fused.setMockLocation(loc)
        } catch (_: SecurityException) {
            Toast.makeText(this, "Seleziona LCGPS come app di posizione simulata.", Toast.LENGTH_LONG).show()
        }
    }
}