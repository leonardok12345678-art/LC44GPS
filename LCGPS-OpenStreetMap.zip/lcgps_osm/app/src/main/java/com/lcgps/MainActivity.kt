package com.lcgps

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

class MainActivity : AppCompatActivity() {
    private lateinit var map: MapView
    private lateinit var fused: FusedLocationProviderClient
    private var marker: Marker? = null
    private var virtual = GeoPoint(41.9028, 12.4964)
    private var mockEnabled = false
    private val step = 0.00025

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE))
        Configuration.getInstance().userAgentValue = packageName
        fused = LocationServices.getFusedLocationProviderClient(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val title = TextView(this).apply {
            text = "  LCGPS  •  OpenStreetMap"
            textSize = 20f
            gravity = Gravity.CENTER_VERTICAL
            setTextColor(0xFF111111.toInt())
            setPadding(16, 8, 16, 8)
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 58))

        map = MapView(this).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(12.0)
            controller.setCenter(virtual)
        }
        root.addView(map, LinearLayout.LayoutParams(-1, 0, 1f))

        val status = TextView(this).apply {
            text = "  Modalità simulazione: disattivata"
            textSize = 14f
            setPadding(16, 10, 16, 10)
        }
        root.addView(status)

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(12, 4, 12, 12)
        }
        val row1 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val up = Button(this).apply { text = "▲" }
        val down = Button(this).apply { text = "▼" }
        row1.addView(up, LinearLayout.LayoutParams(70, 60))
        row1.addView(down, LinearLayout.LayoutParams(70, 60))
        controls.addView(row1)
        val row2 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val left = Button(this).apply { text = "◀" }
        val right = Button(this).apply { text = "▶" }
        row2.addView(left, LinearLayout.LayoutParams(70, 60))
        row2.addView(right, LinearLayout.LayoutParams(70, 60))
        controls.addView(row2)
        val teleport = Button(this).apply { text = "TELETRASPORTA" }
        val enable = Button(this).apply { text = "ABILITA MOCK GPS" }
        controls.addView(teleport)
        controls.addView(enable)
        root.addView(controls)
        setContentView(root)

        addMarker()
        map.setOnTouchListener { _, event ->
            if (event.action == android.view.MotionEvent.ACTION_UP) {
                val geo = map.projection.fromPixels(event.x.toInt(), event.y.toInt())
                virtual = GeoPoint(geo.latitude, geo.longitude)
                addMarker()
                if (mockEnabled) pushMockLocation()
            }
            false
        }

        fun move(dLat: Double, dLng: Double) {
            virtual = GeoPoint(virtual.latitude + dLat, virtual.longitude + dLng)
            addMarker()
            if (mockEnabled) pushMockLocation()
        }
        up.setOnClickListener { move(step, 0.0) }
        down.setOnClickListener { move(-step, 0.0) }
        left.setOnClickListener { move(0.0, -step) }
        right.setOnClickListener { move(0.0, step) }
        teleport.setOnClickListener { addMarker(); if (mockEnabled) pushMockLocation() }
        enable.setOnClickListener {
            if (!isMockLocationApp()) {
                AlertDialog.Builder(this)
                    .setTitle("Attiva LCGPS")
                    .setMessage("Android richiede di selezionare LCGPS come app di posizione simulata nelle Opzioni sviluppatore.")
                    .setPositiveButton("Impostazioni") { _, _ ->
                        startActivity(android.content.Intent(Settings.ACTION_SETTINGS))
                    }.setNegativeButton("Annulla", null).show()
            } else {
                mockEnabled = true
                status.text = "  Modalità simulazione: ATTIVA"
                pushMockLocation()
            }
        }
        requestLocationPermission()
    }

    private fun addMarker() {
        marker?.let { map.overlays.remove(it) }
        marker = Marker(map).apply {
            position = virtual
            title = "LCGPS"
            setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
        }
        map.overlays.add(marker)
        map.controller.animateTo(virtual)
        map.invalidate()
    }

    private fun isMockLocationApp(): Boolean {
        return try {
            Settings.Secure.getString(contentResolver, "mock_location") != null
        } catch (_: Exception) { false }
    }

    private fun pushMockLocation() {
        val loc = Location("LCGPS").apply {
            latitude = virtual.latitude
            longitude = virtual.longitude
            altitude = 0.0
            accuracy = 3f
            speed = 0f
            time = System.currentTimeMillis()
        }
        try {
            fused.setMockMode(true)
            fused.setMockLocation(loc)
        } catch (_: SecurityException) {
            Toast.makeText(this, "Seleziona LCGPS come app di posizione simulata.", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestLocationPermission() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 10)
        }
    }

    override fun onResume() { super.onResume(); if (::map.isInitialized) map.onResume() }
    override fun onPause() { if (::map.isInitialized) map.onPause(); super.onPause() }
    override fun onDestroy() { if (::map.isInitialized) map.onDetach(); super.onDestroy() }
}
