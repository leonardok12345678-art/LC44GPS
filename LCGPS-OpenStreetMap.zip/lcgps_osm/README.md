# LCGPS 1.1 — OpenStreetMap

LCGPS usa OpenStreetMap tramite osmdroid: nessuna Google Maps API key necessaria.

Funzioni incluse: mappa, tap/teletrasporto, marker LCGPS, movimento con joystick e mock GPS tramite Android.

Per usare il mock GPS, seleziona LCGPS come app di posizione simulata nelle Opzioni sviluppatore.
